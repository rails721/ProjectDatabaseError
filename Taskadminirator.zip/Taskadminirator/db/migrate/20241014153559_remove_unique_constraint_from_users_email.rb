class RemoveUniqueConstraintFromUsersEmail < ActiveRecord::Migration[7.2]
  def change
    remove_index :users, :email  # Removes the unique index from the email field
    change_column_null :users, :email, true  # Allows the email to be null
  end
end
