class CreateToUsers < ActiveRecord::Migration[7.2]
  def change
    create_table :to_users do |t|
      t.timestamps
    end
  end
end
