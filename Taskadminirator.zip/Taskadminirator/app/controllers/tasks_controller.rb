class TasksController < ApplicationController
  before_action :authenticate_user!

  def index
    @tasks = Task.all
  end
  
  def new
    @task = Task.new
    @task.comments.build # Initialize one comment field if needed
  end

  def create
    @task = current_user.from_tasks.new(task_params)

    if @task.save
      redirect_to @task, notice: 'Task was successfully created.'
    else
      # Debugging output
      logger.debug @task.errors.full_messages
      render :new
    end
  end

  private

  def task_params
    params.require(:task).permit(:task_name, :status, :task_type, :to_user_id, comments_attributes: [:content, :_destroy])
  end
end
