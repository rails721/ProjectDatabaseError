class ToUser < ApplicationRecord
    has_many :tasks, foreign_key: 'to_user_id'
end
  