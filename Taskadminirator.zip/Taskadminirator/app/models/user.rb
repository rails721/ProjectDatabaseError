class User < ApplicationRecord
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable

  # Validate the username instead of email
  validates :username, presence: true, uniqueness: true

  has_many :from_tasks, class_name: 'Task', foreign_key: 'from_user_id', dependent: :destroy
  has_many :to_tasks, class_name: 'Task', foreign_key: 'to_user_id'
  
  # Disable Devise's email validation
  def email_required?
    false
  end

  def email_changed?
    false
  end
end

